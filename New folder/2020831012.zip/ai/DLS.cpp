// siam arefin reg: 2020831012
#include<bits/stdc++.h>
using namespace std;

// Node class definition
class Node {
public:
    // Constructor
    Node(int value) : value(value) {}

    // Getter for value
    int getValue() const {
        return value;
    }

    // Getter for children
    vector<Node*> getChildren() const {
        return children;
    }

    // Method to add child
    void addChild(Node* child) {
        children.push_back(child);
    }

private:
    int value;
    vector<Node*> children;
};

// AbstractSearch class definition
class AbstractSearch {
public:
    // Constructor
    AbstractSearch(Node* sourceNode, Node* goalNode) : sourceNode(sourceNode), goalNode(goalNode) {}

    // Abstract method execute
    virtual bool execute() = 0;

protected:
    Node* sourceNode;
    Node* goalNode;
};

// DLS class definition, inherits from AbstractSearch
class DLS : public AbstractSearch {
public:
    // Constructor
    DLS(Node* source, Node* goalNode) : AbstractSearch(source, goalNode) {}

    // Execute method
    bool execute() override {
        stack<Node*> nodeStack;
        vector<Node*> visitedNodes;
        nodeStack.push(sourceNode);

        int depth = 0;
        int limit = 2;

        while (!nodeStack.empty()) {
            if (depth <= limit) {
                Node* current = nodeStack.top();
                nodeStack.pop();

                if (current == goalNode) {
                    cout << "Goal node found" << endl;
                    // Print visited nodes
                    for (Node* node : visitedNodes) {
                        cout << node->getValue() << " ";
                    }
                    cout << endl;
                    return true;
                } else {
                    visitedNodes.push_back(current);
                    vector<Node*> children = current->getChildren();
                    for (Node* child : children) {
                        nodeStack.push(child);
                    }
                    depth++;
                }
            } else {
                cout << "Goal Node not found within depth limit" << endl;
                return false;
            }
        }

        return false;
    }
};

int main() {
    // Creating nodes
    Node* node1 = new Node(1);
    Node* node2 = new Node(2);
    Node* node3 = new Node(3);
    Node* node4 = new Node(4);

    // Building the tree structure
    node1->addChild(node2);
    node1->addChild(node3);
    node2->addChild(node4);

    // Creating DLS object
    DLS dls(node1, node4);

    // Executing DLS
    dls.execute();

    // Freeing allocated memory
    delete node1;
    delete node2;
    delete node3;
    delete node4;

    return 0;
}
