import java.util.ArrayList;
import java.util.Stack;

public class DLS_IDS {
    

        // DLS -Depth Limited Search

        public static void dls(ArrayList<Edge> graph[], int curr, int depth, boolean vis[]) {
            // If depth limit is reached or exceeded, return
            if (depth == 0)
                return;
            // If the current node is already visited, return
            if (vis[curr])
                return;
            // Print the current node
            System.out.print(curr + " ");
            // Mark the current node as visited
            vis[curr] = true;
            // Traverse all adjacent nodes of the current node within depth limit
            for (int i = 0; i < graph[curr].size(); i++) {
                dls(graph, graph[curr].get(i).des, depth - 1, vis);
            }
        }





        // IDS -Iterative Deepening Depth-First Search

        public static boolean ids(ArrayList<Edge> graph[], int start, int target, int maxDepth) {
        
            Stack<Integer> stack = new Stack<>();
   
            boolean[] visited = new boolean[graph.length];
            
      
            stack.push(start);
            
      
            while (!stack.isEmpty()) {
            
                int curr = stack.pop();
                
                // If the current node is the target node, return true
                if (curr == target)
                    return true;
                
                // Mark the current node as visited
                visited[curr] = true;
                
                // If the current depth is less than the maximum depth, explore further
                if (stack.size() < maxDepth) {
                    // Push unvisited adjacent nodes to the stack
                    for (Edge neighbor : graph[curr]) {
                        if (!visited[neighbor.des])
                            stack.push(neighbor.des);
                    }
                }
            }
            
            // Target node not found within the maximum depth limit
            return false;
        }


}
