
import java.util.*;

public class BFS_DFS {
    


 //BFS Function

    public static void bfs(ArrayList<Edge> graph[], int V) {
        boolean visited[] = new boolean[V];
        Queue<Integer> q = new LinkedList<>();
        q.add(0); //Source = 0


        while(!q.isEmpty()) {

        int curr = q.remove();


        if(!visited[curr])
         {

        System.out.print(curr+" ");
        visited[curr] = true;
        for(int i=0; i<graph[curr].size(); i++)
         {
        Edge e = (Edge) graph[curr].get(i);
        q.add(e.des);



        }
        }
        
    }
        System.out.println();
        }






        //DFS Function

        public static void dfs(ArrayList<Edge>graph[],int curr,boolean vis[])
        {
            if(vis[curr]) return;
        System.out.print(curr+" ");
        vis[curr]=true;
        for (int i = 0; i < graph[curr].size(); i++) {
            dfs(graph, graph[curr].get(i).des, vis);

        }





        }





    }




