#include <iostream>
#include <list>
#include <vector>
#include <stack>

using namespace std;

// Graph class represents a directed graph using adjacency list representation
class Graph {
    int V; // No. of vertices

    // Pointer to an array containing adjacency lists
    list<int> *adj;

public:
    Graph(int V); // Constructor
    void addEdge(int v, int w); // Function to add an edge to graph
    bool DLS(int v, int target, int depth_limit); // Depth-limited search
};

Graph::Graph(int V) {
    this->V = V;
    adj = new list<int>[V];
}

void Graph::addEdge(int v, int w) {
    adj[v].push_back(w); // Add w to v�s list.
}

bool Graph::DLS(int v, int target, int depth_limit) {
    if (v == target)
        return true;

    if (depth_limit <= 0)
        return false;

    // Recur for all the vertices adjacent to this vertex
    for (auto i = adj[v].begin(); i != adj[v].end(); ++i)
        if (DLS(*i, target, depth_limit - 1) == true)
            return true;

    return false;
}

int main() {
    Graph g(7); // Total 7 vertices in the graph

    // Example graph
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.addEdge(2, 5);
    g.addEdge(2, 6);

    int depth_limit = 3; // Limiting depth
    int target = 6; // Target node to search
    int start = 0; // Start node

    if (g.DLS(start, target, depth_limit))
        cout << "Target " << target << " is reachable from node " << start << " within depth limit " << depth_limit << endl;
    else
        cout << "Target " << target << " is not reachable from node " << start << " within depth limit " << depth_limit << endl;

    return 0;
}

