#include <iostream>
#include <vector>

using namespace std;

// Define a structure for a node in the graph
struct Node {
    int data;
    vector<Node*> neighbors;

    // Constructor to initialize the node with data
    Node(int value) : data(value) {}
};

// Depth-First Search function
// Parameters:
// - node: current node being explored
// - target: the value being searched for
// - depth: current depth in the search
bool DFS(Node* node, int target, int depth) {
    // Check if the node is null or if the target is found
    if (node == nullptr)
        return false;
    if (node->data == target) {
        cout << "Target " << target << " found at depth " << depth << endl;
        return true;
    }

    // If depth limit is reached, return false
    if (depth <= 0)
        return false;

    // Recursively search the neighbors of the current node
    for (Node* neighbor : node->neighbors) {
        bool result = DFS(neighbor, target, depth - 1);
        if (result)
            return true; // If target is found in any neighbor, return true
    }

    // If the target is not found in any neighbors, return false
    return false;
}

// Iterative Deepening Depth-First Search function
// Parameters:
// - root: the root node of the graph
// - target: the value being searched for
// - maxDepth: maximum depth to explore
bool IDS(Node* root, int target, int maxDepth) {
    // Iterate from depth 0 to maxDepth
    for (int depth = 0; depth <= maxDepth; ++depth) {
        cout << "Depth limit: " << depth << endl;
        if (DFS(root, target, depth)) // Perform DFS with current depth limit
            return true; // If target is found, return true
    }
    // If target is not found within the maximum depth, return false
    return false;
}

// Example usage
int main() {
    // Create a sample graph
    Node* node1 = new Node(1);
    Node* node2 = new Node(2);
    Node* node3 = new Node(3);
    Node* node4 = new Node(4);
    Node* node5 = new Node(5);

    node1->neighbors.push_back(node2);
    node1->neighbors.push_back(node3);
    node2->neighbors.push_back(node4);
    node3->neighbors.push_back(node5);

    int target = 5;
    int maxDepth = 3; // Maximum depth to explore

    // Perform Iterative Deepening Depth-First Search from node1 with maximum depth 3
    bool result = IDS(node1, target, maxDepth);

    if (!result)
        cout << "Target " << target << " not found within maximum depth." << endl;

    // Free memory allocated for nodes (not essential in many cases, but good practice)
    delete node1;
    delete node2;
    delete node3;
    delete node4;
    delete node5;

    return 0;
}
