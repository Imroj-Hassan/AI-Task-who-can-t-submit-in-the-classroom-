#include <iostream>
#include <vector>
#include <stack>

using namespace std;

// Define a structure for a node in the graph
struct Node {
    int data;
    vector<Node*> neighbors;

    // Constructor to initialize the node with data
    Node(int value) : data(value) {}
};

// Depth-Limited Search function
// Parameters:
// - node: current node being explored
// - target: the value being searched for
// - depth: current depth in the search
// - limit: depth limit for the search
bool DLS(Node* node, int target, int depth, int limit) {
    // Check if the node is null or if the depth limit has been reached
    if (node == nullptr || depth > limit)
        return false;

    // Check if the target value is found at the current node
    if (node->data == target) {
        cout << "Target " << target << " found at depth " << depth << endl;
        return true;
    }

    // Recursively search the neighbors of the current node
    for (Node* neighbor : node->neighbors) {
        bool result = DLS(neighbor, target, depth + 1, limit);
        if (result)
            return true; // If target is found in any neighbor, return true
    }

    // If the target is not found in any neighbors, return false
    return false;
}

// Example usage
int main() {
    // Create a sample graph
    Node* node1 = new Node(1);
    Node* node2 = new Node(2);
    Node* node3 = new Node(3);
    Node* node4 = new Node(4);
    Node* node5 = new Node(5);

    node1->neighbors.push_back(node2);
    node1->neighbors.push_back(node3);
    node2->neighbors.push_back(node4);
    node3->neighbors.push_back(node5);

    int target = 5;
    int depthLimit = 2;

    // Perform Depth-Limited Search with depth limit 2 starting from node1
    bool result = DLS(node1, target, 0, depthLimit);

    if (!result)
        cout << "Target " << target << " not found within depth limit." << endl;

    // Free memory allocated for nodes (not essential in many cases, but good practice)
    delete node1;
    delete node2;
    delete node3;
    delete node4;
    delete node5;

    return 0;
}
