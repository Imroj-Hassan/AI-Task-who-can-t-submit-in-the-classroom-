
#include<bits/stdc++.h>
using namespace std;



int main(){
	
 
int n,edge,endgoal=0,target,maxlevel;
cin >> n >>  target >> edge >> maxlevel;
vector<vector<int>> adj(n+1,vector<int>()); 
queue<int> q;
vector<int>d(n+1,0);
while(edge--){
	int x,y;
	cin >>x >> y;
	adj[x].push_back(y);
	}

int s =1;
q.push(s);

d[s]=0;
while (!q.empty()) {
    int v = q.front();
    cout << v <<' ';
    if(v==target){
		endgoal=1;
		break;
		}
    q.pop();
    for (int u : adj[v]) {
        if (maxlevel>=d[v]+1){//this is where it changes....
          
            q.push(u);
            d[u] = d[v] + 1;
          
			}
		}
	}
	if(endgoal==1){
		cout <<"Path exists for goal" << '\n';
		}
	else{
		cout << "Path does not exist for goal" << '\n';
		}
	return 0;
	}
/*
 Input-1
5 2 4 1
1 3
1 4
1 2
2 5
Output -1
1 3 4 2 Path exists for goal

Input-2
5 5 4 1
1 3
1 4
1 2
2 5
Output-2
1 3 4 2 Path does not exist for goal*/

