#include <iostream>
#include <vector>
#include <stack>

using namespace std;

// Define a graph using an adjacency list
vector<vector<int>> graph;

// Function to perform Depth-Limited Search
bool DLS(int start, int goal, int depth) {
    // Stack to keep track of nodes to be visited
    stack<pair<int, int>> s;  // Pair: (node, depth)

    // Push the starting node and its depth
    s.push({start, 0});

    while (!s.empty()) {
        // Get the current node and its depth
        int current = s.top().first;
        int currentDepth = s.top().second;
        s.pop();

        // Check if the goal is reached
        if (current == goal) {
            cout << "Goal found at depth: " << currentDepth << endl;
            return true;
        }

        // If depth limit is not reached, continue exploring
        if (currentDepth < depth) {
            // Iterate over neighbors and push them to the stack
            for (int neighbor : graph[current]) {
                s.push({neighbor, currentDepth + 1});
            }
        }
    }

    return false;  // Goal not found within the depth limit
}

int main() {
    // Initialize the graph (example graph)
    graph = {
        {1, 2},     // Node 0 is connected to nodes 1 and 2
        {3, 4},     // Node 1 is connected to nodes 3 and 4
        {5},        // Node 2 is connected to node 5
        {6, 7},     // Node 3 is connected to nodes 6 and 7
        {},         // Node 4 has no outgoing edges
        {8},        // Node 5 is connected to node 8
        {9},        // Node 6 is connected to node 9
        {},         // Node 7 has no outgoing edges
        {},         // Node 8 has no outgoing edges
        {}          // Node 9 has no outgoing edges
    };

    int startNode = 0;
    int goalNode = 8;
    int depthLimit = 3;

    // Perform Depth-Limited Search
    bool goalFound = DLS(startNode, goalNode, depthLimit);

    if (!goalFound) {
        cout << "Goal not found within the depth limit." << endl;
    }

    return 0;
}
