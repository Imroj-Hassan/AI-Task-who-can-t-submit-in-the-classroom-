#include <iostream>
#include <vector>
using namespace std;

// Function to perform depth-limited search from a given node
bool DLS(int node, int target, int depth, vector<vector<int>>& graph) {
    if (depth == 0 && node == target) // If target is found at the specified depth
        return true;
    if (depth > 0) {
        for (int neighbor : graph[node]) {
            if (DLS(neighbor, target, depth - 1, graph)) // Recursively search neighbors at reduced depth
                return true;
        }
    }
    return false; // Target not found at this depth
}

// Function to perform Iterative Deepening Search
bool IDS(int start, int target, int maxDepth, vector<vector<int>>& graph) {
    for (int depth = 0; depth <= maxDepth; ++depth) {
        if (DLS(start, target, depth, graph)) // Perform DLS with increasing depth limits
            return true;
    }
    return false; // Target not found within maximum depth limit
}

int main() {
    int n; // Number of nodes
    cout << "Enter the number of nodes: ";
    cin >> n;

    vector<vector<int>> graph(n); // Adjacency list representation of the graph

    int m; // Number of edges
    cout << "Enter the number of edges: ";
    cin >> m;

    cout << "Enter the edges (from -> to):" << endl;
    for (int i = 0; i < m; ++i) {
        int from, to;
        cin >> from >> to;
        graph[from].push_back(to); // Add directed edge
    }

    int start, target, maxDepth;
    cout << "Enter the starting node: ";
    cin >> start;
    cout << "Enter the target node: ";
    cin >> target;
    cout << "Enter the maximum depth: ";
    cin >> maxDepth;

    if (IDS(start, target, maxDepth, graph))
        cout << "Target found within maximum depth limit." << endl;
    else
        cout << "Target not found within maximum depth limit." << endl;

    return 0;
}
