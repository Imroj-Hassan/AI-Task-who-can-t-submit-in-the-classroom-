import java.util.ArrayList;
import java.util.Stack;

public class IDSDLS {
    


        

        // IDS  CODE

        public static boolean ids(ArrayList<Edge> graph[], int start, int target, int maxDepth) {
        
            Stack<Integer> stack = new Stack<>();
   
            boolean[] visited = new boolean[graph.length];
            
      
            stack.push(start);
            
      
            while (!stack.isEmpty()) {
            
                int curr = stack.pop();
                
    
                if (curr == target)
                    return true;
     
                visited[curr] = true;
                
           
                if (stack.size() < maxDepth) {
        
                    for (Edge neighbor : graph[curr]) {
                        if (!visited[neighbor.des])
                            stack.push(neighbor.des);
                    }
                }
            }
            
        
            return false;
        }







        // DLS CODE

        public static void dls(ArrayList<Edge> graph[], int curr, int depth, boolean vis[]) {
     
            if (depth == 0)
                return;

            if (vis[curr])
               return;
            System.out.println(curr + " ");
            vis[curr] = true;
            for (int i = 0; i < graph[curr].size(); i++) {
                dls(graph, graph[curr].get(i).des, depth - 1, vis);
            }
        }





}
